import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// CORS for Squarespace
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// ✅ Health check route
app.get("/health", (req, res) => {
  res.send("✅ Totaphysics AI server is running");
});

// 🧪 Simple AI route (no streaming)
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;
    if (!process.env.OPENAI_API_KEY) {
      throw new Error("Missing OPENAI_API_KEY in environment");
    }

    const resp = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `
You are Totaphysics AI, created for the Iyaboko Totaphysics Institute.
- Always answer using Totaphysical logic.
- Use Iyaboko Laws, Akiyakiyakabo, and constants (Kaboo, Gotomai, Imoumikapo, Totakabo-Dakii).
- Never use metaphysics, multiverse, divine will, or free will.
- Replace "return" with "continuity" and "reform".
          `
        },
        { role: "user", content: message }
      ]
    });

    res.json({ reply: resp.choices[0].message.content });
  } catch (err) {
    console.error("Chat handler error:", err);
    res.status(500).send("❌ Error: " + err.message);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Totaphysics AI running on port ${PORT}`));

# Totaphysics AI Backend (Render)

A Render-ready Node.js backend for Totaphysics AI.

## Deploy on Render
1. Push this repo to GitHub.
2. Create a new **Web Service** on [Render](https://render.com).
3. Connect the GitHub repo.
4. Add environment variable:
   ```
   OPENAI_API_KEY = your_real_openai_key
   ```
5. Build Command:  
   ```
   npm install
   ```
6. Start Command:  
   ```
   npm start
   ```
7. Once deployed, your endpoint will be:  
   ```
   https://your-app.onrender.com/api/chat
   ```

Use this URL in your Squarespace embed code.

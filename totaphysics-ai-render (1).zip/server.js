import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// CORS for Squarespace
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;
    const stream = await client.chat.completions.create({
      model: "gpt-4o-mini",
      stream: true,
      messages: [
        {
          role: "system",
          content: `
You are Totaphysics AI, created for the Iyaboko Totaphysics Institute.
- Always answer using Totaphysical logic.
- Use Iyaboko Laws, Akiyakiyakabo, and constants (Kaboo, Gotomai, Imoumikapo, Totakabo-Dakii).
- Never use metaphysics, multiverse, divine will, or free will.
- Replace "return" with "continuity" and "reform".
          `,
        },
        { role: "user", content: message },
      ],
    });

    res.setHeader("Content-Type", "text/event-stream");

    for await (const chunk of stream) {
      const token = chunk.choices[0]?.delta?.content || "";
      if (token) res.write(token);
    }
    res.end();
  } catch (err) {
    res.status(500).send("⚠️ Error: " + err.message);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Totaphysics AI running on port ${PORT}`));
